#!/bin/bash

java -jar ./trueno-elastic-bridge-server.jar $1 $2
